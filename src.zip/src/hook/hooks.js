import React, { useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';

import { authReducer, setCurrentMode, addSchedule, delSchedule, modSchedule } from '../store/index'

export const useMessage = () => {

    const dispatch = useDispatch()
    
    const toDos = useSelector((state) => state.toDoManager.todo)
    
    const getUser = useSelector((state) => state.toDoManager.authLevel)
    const setUser = (level) => dispatch ( authReducer(level) )

    const getMode = useSelector((state) => state.toDoManager.currentMode)
    const setMode = (type) => dispatch( setCurrentMode( type ))

    const addToDo = (todo) => dispatch( addSchedule(todo) )
    const delToDo = (todo) => dispatch( delSchedule(todo) )
    const modToDo = (todo) => dispatch( modSchedule(todo) )

    return { toDos, getUser, getMode, setUser, setMode, addToDo, delToDo, modToDo }
    
}
  