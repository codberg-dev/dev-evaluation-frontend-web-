import { configureStore, createSlice } from "@reduxjs/toolkit";
import { act } from "react-dom/test-utils";

const initialState = {
    authLevel: 2, // 0: admin, 1: user, 2: not logged in
    currentMode : "",
    todo: [
        // {title: "example", content: "example content"}
    ]
}

const toDoManager = createSlice({
    name: 'manager', initialState, reducers: {
        authReducer(state, action){
            state.authLevel = action.payload
        },
        setCurrentMode(state, action){
            state.currentMode = action.payload
        },
        addSchedule(state, action) {
            if (action.payload.title === "") alert("할 일을 입력하세요.")
            else {
                state.todo = [...state.todo, action.payload]
                alert("할 일이 추가되었습니다.")
            }
        },
        delSchedule(state, action){
            // state.todo.filter((t) => t.id !== action.payload) // filter 보다 이게 나을 듯
            const index = state.todo.findIndex((t) => t.id === action.payload)
            state.todo.splice(index, 1)
            alert("삭제되었습니다.")
        },
        modSchedule(state, action){
            const index = state.todo.findIndex((t) => t.id === action.payload.id)
            state.todo[index] = action.payload
            alert("수정되었습니다.")
        }
    } 
})

export const { authReducer, setCurrentMode, addSchedule, delSchedule, modSchedule } = toDoManager.actions;

export default configureStore({
    reducer: {
        toDoManager: toDoManager.reducer
    }
})