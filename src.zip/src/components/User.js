import React, { useEffect, useState } from 'react'
import { useMessage } from '../hook/hooks'

function User() {

    const { toDos, setMode, getUser, setUser } = useMessage()

    const [userInput, setUserInput] = useState({
        id: "", pw: ""
    })

    const handleSubmit = () => {

        if (userInput.id === "test" && userInput.pw === "test") {
            setUser(1);
            alert("어서오세요!")
            setUserInput({id: "", pw: ""})
        }
        else if (userInput.id === "" || userInput.pw === "") {
            alert("정보를 입력해 주세요.")
        }
        else {
            alert('존재하지 않는 회원 입니다.')
            setUserInput({id: "", pw: ""})
        }
    }

    return (
        <div className='sub-container-inner'>
            {
            
            getUser <= 1 ?

            <>
                <div>
                    <span>어서오세요. $user.id님!!</span>
                    <a
                    style={{cursor: 'pointer', color: 'blue'}}
                    onClick={() => {
                        setUser(2)
                        alert('로그아웃 되었습니다.')
                    }}
                    
                    > 로그아웃</a>
                </div>
            </>

            :

            <>
                <div className='container-head'>
                    <p>로그인하셔서 할 일을 관리해 보세요 (test / test)</p>
                </div>
                <input type='text' placeholder='ID' value={userInput.id}
                onChange={(e) => {
                    setUserInput({...userInput, id: e.target.value})
                }}></input>
                <input type='text' placeholder='Password' value={userInput.pw}
                onChange={(e) => {
                    setUserInput({...userInput, pw: e.target.value})
                }}></input>
                <button onClick={() => {handleSubmit()}}>로그인</button>
            </>
            }
        </div>
    )
}

export default User