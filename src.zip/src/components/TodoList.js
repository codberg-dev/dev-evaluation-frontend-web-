import React, { useEffect } from 'react'
import { useMessage } from '../hook/hooks'

function TodoList(props) {

    const { toDos, getUser, setMode } = useMessage()

    return (
        <div className='your-todo-list'>

            {
                toDos.length === 0 ?
                
                <p className='add-please'>할 일을 추가해 주세요.</p>

                :

                <ul>
                    {toDos.map((todo, idx) =>
                        <li key={idx} className='todo' onClick={()=> {
                            setMode('manage');
                            props.setCurrentId(todo.id);
                        }}>
                            <span>{todo.title}</span>
                        </li>)}
                </ul>


            }

            <div className='create-schedule-btn'>
                <button onClick={()=>{
                    if (getUser <= 1) {
                        setMode('add')
                    } else if (getUser > 1) {
                        alert("로그인 해주세요!")
                    }
                    
                }}>+</button>
            </div>

        </div>
    )
}

export default TodoList